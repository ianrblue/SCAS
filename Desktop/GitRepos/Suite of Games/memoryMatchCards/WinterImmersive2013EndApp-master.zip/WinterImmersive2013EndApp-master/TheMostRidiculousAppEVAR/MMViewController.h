//
//  MMViewController.h
//  TheMostRidiculousAppEVAR
//
//  Created by mmacademy on 3/28/13.
//  Copyright (c) 2013 mmacademy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CardView.h"

@interface MMViewController : UIViewController
- (IBAction)purpleCardTapped:(UITapGestureRecognizer *)sender;
@property (weak, nonatomic) IBOutlet CardView *purpleCard;



@end
