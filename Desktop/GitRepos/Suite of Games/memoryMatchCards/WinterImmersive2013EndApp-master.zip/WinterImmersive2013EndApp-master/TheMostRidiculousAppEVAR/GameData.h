//
//  GameData.h
//  TheMostRidiculousAppEVAR
//
//  Created by mmacademy on 3/28/13.
//  Copyright (c) 2013 mmacademy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GameData : NSObject
{
    
}
@property (assign, nonatomic) int totalCardsInDeck;
@property (assign, nonatomic) int suits;
@property (assign, nonatomic) int cardValue;
@property (strong, nonatomic) NSArray *deckOfCards;

@end
