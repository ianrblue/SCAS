//
//  MMViewController.m
//  TheMostRidiculousAppEVAR
//
//  Created by mmacademy on 3/28/13.
//  Copyright (c) 2013 mmacademy. All rights reserved.
//

#import "MMViewController.h"
#import "CardView.h"

@interface MMViewController ()
{
    BOOL flipped;
    CardView *gameCard;
    
    CGFloat cardWidth;
    CGFloat cardHeight;
    CGFloat cardMargin;
}


@end

@implementation MMViewController
@synthesize purpleCard;

- (void)viewDidLoad
{
    [super viewDidLoad];
    flipped = NO;


    
    
    NSLog(@"%f",self.view.frame.size.width);
    NSLog(@"%f",self.view.frame.size.height);
    
    [self setupLayoutWithColumns:10 Rows:10];
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)purpleCardTapped:(UITapGestureRecognizer *)sender
{
    //when purplecard is clicked flip it.
    if (flipped == NO)
    {
        purpleCard.backgroundColor = [UIColor purpleColor];
        flipped = YES;
        //dont allow to click again until another card is clicked to see if it matches
    } else if (flipped == YES)
    {
        purpleCard.backgroundColor = [UIColor blueColor];
        flipped = NO;
    }
}

-(void)setupLayoutWithColumns:(int)numCols Rows:(int)numRows
{
    
    //setup card pieces
    
    int xPadding = 5;
    cardWidth = (self.view.frame.size.width / numCols) - xPadding;
    
    int yPadding = 5;
    cardHeight = (self.view.frame.size.height / numRows) - yPadding;
                 
    

    //cardHeight = 100.0f;
    
    cardMargin = xPadding /2;
    
    CGFloat x, y;
    
    
    int startingValue = (xPadding /2);
    x = y = startingValue;
    int i = 1;
    while (y < self.view.frame.size.height)
    {
        while(x < self.view.frame.size.width)
        {
            CardView* aCard = [[CardView alloc] init];
            
            //Place card
            aCard.frame = CGRectMake(x, y, cardWidth, cardHeight);
            [self.view addSubview:aCard];
            
            //setup additional card properties
            aCard.backgroundColor = aCard.cardColor;
            aCard.CardNumber = i;
            i++;
            
            x += (cardWidth + xPadding);
            //NSLog(@"x = %f", x);
        }

        x = startingValue;
        y += (cardHeight + yPadding);
        //NSLog(@"y = %f", y);
    }
    
}

@end
