//
//  GameData.m
//  TheMostRidiculousAppEVAR
//
//  Created by mmacademy on 3/28/13.
//  Copyright (c) 2013 mmacademy. All rights reserved.
//

#import "GameData.h"

@implementation GameData

@synthesize totalCardsInDeck, suits, cardValue, deckOfCards;

- (GameData *)initGame
{
    totalCardsInDeck = 12;
    suits = 6;
    // Create cards and save in deck
}

@end
