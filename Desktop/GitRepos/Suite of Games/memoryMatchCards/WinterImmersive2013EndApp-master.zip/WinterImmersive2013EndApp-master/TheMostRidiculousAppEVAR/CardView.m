//
//  Card.m
//  TheMostRidiculousAppEVAR
//
//  Created by mmacademy on 3/28/13.
//  Copyright (c) 2013 mmacademy. All rights reserved.
//

#import "CardView.h"

@implementation CardView
@synthesize isFlipped, isSolved, cardColor, CardNumber;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.cardColor = [UIColor greenColor];
        self.CardNumber = 0;
    }
    return self;
}

- (CardView *)initCard:(NSInteger)numberOfCard
{
    NSArray *cardColors = [[NSArray alloc] initWithObjects:[UIColor blueColor], [UIColor greenColor], [UIColor redColor], [UIColor yellowColor], [UIColor blackColor], [UIColor orangeColor] , nil];
    
    cardColor = [cardColors objectAtIndex:numberOfCard];
    
    return self;
}
-(void) setCardColor:(UIColor*)color
{
    cardColor = color;
    [self setBackgroundColor:color];
}

//Flip animation
-(void)flipCard
{   
//    [self setCardColor:[UIColor blueColor]];
    cardColor = [UIColor blueColor];
//    UIImageView * cardBack;
    if (self.isFlipped == NO)
    {
        
    
    [UIView transitionWithView:self duration:0.75 options:UIViewAnimationOptionTransitionFlipFromRight animations:^{
        self.backgroundColor = cardColor;}
                    completion:^(BOOL finished)
                    {
                        self.isFlipped = YES;
                    }];
    }
    else
    {
        //Flip card back to default color (here, green)
        cardColor = [UIColor greenColor];
        [UIView transitionWithView:self duration:0.75 options:UIViewAnimationOptionTransitionFlipFromRight animations:^{
            self.backgroundColor = cardColor;}
                        completion:^(BOOL finished)
         {
             self.isFlipped = NO;
         }];
    }
}


#pragma mark - touch stuff

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"CARD %d WAS TOUCHED!",self.CardNumber);
    [self flipCard];
//    NSSet *allTouches = [event allTouches];
//    for (UITouch *touch in allTouches)
//    {
//        //CGPoint location = [touch locationInView:touch.view];
//        [self flipCard];
//        
//    }
}





#pragma mark -- End of document
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
