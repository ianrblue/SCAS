//
//  TheMostRidiculousAppEVARTests.m
//  TheMostRidiculousAppEVARTests
//
//  Created by mmacademy on 3/28/13.
//  Copyright (c) 2013 mmacademy. All rights reserved.
//

#import "TheMostRidiculousAppEVARTests.h"

@implementation TheMostRidiculousAppEVARTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in TheMostRidiculousAppEVARTests");
}

@end
