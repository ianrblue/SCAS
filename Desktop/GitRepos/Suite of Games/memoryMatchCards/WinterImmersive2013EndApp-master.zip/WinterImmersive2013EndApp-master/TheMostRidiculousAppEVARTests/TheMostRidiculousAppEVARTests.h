//
//  TheMostRidiculousAppEVARTests.h
//  TheMostRidiculousAppEVARTests
//
//  Created by mmacademy on 3/28/13.
//  Copyright (c) 2013 mmacademy. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface TheMostRidiculousAppEVARTests : SenTestCase

@end
